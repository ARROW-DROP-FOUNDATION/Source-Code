export interface WishData {
  id: string;
  name: string;
  relationship: string;
  message: string;
  animationType: 'family' | 'friends' | 'husband';
}

export interface TimelineEvent {
  date: string;
  title: string;
  description: string;
}