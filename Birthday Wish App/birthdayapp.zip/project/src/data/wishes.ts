import { WishData, TimelineEvent } from '../types';

export const familyWishes: WishData[] = [
  {
    id: 'wish-1',
    name: 'Kaleem Basha S',
    relationship: 'Father',
    message: "Happy birthday to my precious daughter. You've grown into such an amazing woman, mother, and wife. May Allah bless you with happiness and health always.",
    animationType: 'family'
  },
  {
    id: 'wish-2',
    name: 'Asmath K',
    relationship: 'Mother',
    message: "My dearest Shayin, watching you grow into the wonderful person you are today has been life's greatest blessing. Happy 33rd birthday!",
    animationType: 'family'
  },
  {
    id: 'wish-3',
    name: 'Umi K',
    relationship: 'Sister',
    message: "Happy birthday sister! You've always been my role model and best friend. Wishing you all the happiness in the world.",
    animationType: 'family'
  },
  {
    id: 'wish-4',
    name: 'Farzana S',
    relationship: 'Sister',
    message: 'To my amazing sister on her special day. May your birthday be as beautiful as you are!',
    animationType: 'family'
  },
  {
    id: 'wish-5',
    name: 'Famidha U',
    relationship: 'Sister',
    message: 'Happy birthday Shayin! Thank you for always being there for me. Love you loads!',
    animationType: 'family'
  },
  {
    id: 'wish-6',
    name: 'Afrin K',
    relationship: 'Sister',
    message: 'Wishing the most special sister a very happy birthday. May Allah grant all your wishes!',
    animationType: 'family'
  }
];

export const friendWishes: WishData[] = [
  {
    id: 'wish-7',
    name: 'Sushmita & Family',
    relationship: 'School Friend',
    message: 'Happy birthday to my oldest and dearest friend! Remember all our school adventures? Here\'s to many more years of friendship!',
    animationType: 'friends'
  },
  {
    id: 'wish-8',
    name: 'Shanti & Family ',
    relationship: 'School Friend',
    message: 'Happy 34th birthday Rasheedha! Those school days feel like yesterday. Wishing you all the happiness today and always!',
    animationType: 'friends'
  },
  {
    id: 'wish-9',
    name: 'Logesh & Family',
    relationship: 'School Friend',
    message: 'To my wonderful friend, may your birthday be as special as you are. Miss our school days!',
    animationType: 'friends'
  }
];

export const husbandWish: WishData = {
  id: 'wish-10',
  name: 'Munna A',
  relationship: 'Husband',
  message: "Happy birthday to my beautiful wife, my Dhillu. These 12 years of marriage have been the best years of my life. You are the light of our home and the keeper of my heart. I love you more with each passing day. Here's to celebrating many more birthdays together!",
  animationType: 'husband'
};

export const timelineEvents: TimelineEvent[] = [
  {
    date: 'May 6, 1992',
    title: 'A Star Was Born',
    description: 'Rasheedha M was born, bringing joy to her family'
  },
  {
    date: '2012',
    title: 'Educational Milestone',
    description: 'Completed +2 education'
  },
  {
    date: 'February 28, 2013',
    title: 'Wedding Day',
    description: 'Married Munna A, beginning a beautiful journey together'
  },
  {
    date: 'March 12, 2014',
    title: 'First Bundle of Joy',
    description: 'Welcomed first daughter Haasheedha M into the world'
  },
  {
    date: 'July 20, 2017',
    title: 'Growing Family',
    description: 'Blessed with second daughter Hasina M'
  }
];