import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Timeline from './components/Timeline';
import WishGallery from './components/WishGallery';

function App() {
  const [isMusicPlaying, setIsMusicPlaying] = useState<boolean>(false);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);
  
  useEffect(() => {
    // Create audio element for background music
    const audio = new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3');
    audio.loop = true;
    setAudioElement(audio);
    
    return () => {
      if (audio) {
        audio.pause();
        audio.src = '';
      }
    };
  }, []);
  
  const toggleMusic = () => {
    if (audioElement) {
      if (isMusicPlaying) {
        audioElement.pause();
      } else {
        audioElement.play();
      }
      setIsMusicPlaying(!isMusicPlaying);
    }
  };
  
  return (
    <div className="min-h-screen bg-pink-50">
      <Header isMusicPlaying={isMusicPlaying} toggleMusic={toggleMusic} />
      <Hero />
      <Timeline />
      <WishGallery />
      <footer className="py-6 bg-pink-100 text-center text-pink-600">
        <p>With love on your 34th birthday, Rasheedha ❤️</p>
        <p className="text-sm mt-2">May 6, 2026</p>
      </footer>
    </div>
  );
}

export default App;