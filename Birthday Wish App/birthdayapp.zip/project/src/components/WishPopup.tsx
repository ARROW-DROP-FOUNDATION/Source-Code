import React, { useState, useEffect } from 'react';
import { WishData } from '../types';
import { X } from 'lucide-react';

interface WishPopupProps {
  wish: WishData;
  onClose: () => void;
  isOpen: boolean;
}

const WishPopup: React.FC<WishPopupProps> = ({ wish, onClose, isOpen }) => {
  const [animationClass, setAnimationClass] = useState('');
  
  useEffect(() => {
    if (isOpen) {
      // Different animation based on wish type
      if (wish.animationType === 'family') {
        setAnimationClass('animate-family-wish');
      } else if (wish.animationType === 'friends') {
        setAnimationClass('animate-friends-wish');
      } else if (wish.animationType === 'husband') {
        setAnimationClass('animate-husband-wish');
      }
    }
  }, [isOpen, wish.animationType]);
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/50 backdrop-blur-sm">
      <div 
        className={`relative bg-white rounded-xl shadow-2xl max-w-lg w-full mx-4 p-6 ${animationClass}`}
        style={{
          boxShadow: wish.animationType === 'husband' 
            ? '0 0 30px rgba(244, 114, 182, 0.6), 0 0 60px rgba(244, 114, 182, 0.4)'
            : ''
        }}
      >
        <button 
          onClick={onClose}
          className="absolute top-2 right-2 p-1 rounded-full hover:bg-gray-100 transition-colors"
          aria-label="Close"
        >
          <X size={20} className="text-gray-500" />
        </button>
        
        <div className={`flex flex-col items-center text-center ${
          wish.animationType === 'husband' ? 'husband-special-style' : ''
        }`}>
          {wish.animationType === 'husband' && (
            <div className="absolute inset-0 overflow-hidden rounded-xl pointer-events-none">
              {[...Array(20)].map((_, i) => (
                <div 
                  key={i}
                  className="absolute animate-float-fast"
                  style={{
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                    width: '10px',
                    height: '10px',
                    background: `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 0.7)`,
                    borderRadius: '50%',
                    animationDelay: `${Math.random() * 2}s`,
                    animationDuration: `${1 + Math.random() * 2}s`
                  }}
                />
              ))}
            </div>
          )}
          
          <div className={`text-xl font-semibold mb-1 ${
            wish.animationType === 'family' ? 'text-teal-600' : 
            wish.animationType === 'friends' ? 'text-blue-600' : 'text-pink-600 font-dancing text-2xl'
          }`}>
            {wish.name}
          </div>
          
          <div className="text-sm text-gray-500 mb-4">{wish.relationship}</div>
          
          <p className={`text-gray-700 mb-4 ${
            wish.animationType === 'husband' ? 'text-lg italic leading-relaxed' : ''
          }`}>
            "{wish.message}"
          </p>
          
          {wish.animationType === 'husband' && (
            <div className="mt-2 text-pink-500">
              ❤️ With all my love ❤️
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WishPopup;