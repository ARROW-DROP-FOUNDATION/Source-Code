import React, { useEffect, useState } from 'react';
import { Heart, Calendar, Star } from 'lucide-react';

const Hero: React.FC = () => {
  const [days, setDays] = useState<number>(0);
  const [hours, setHours] = useState<number>(0);
  const [minutes, setMinutes] = useState<number>(0);
  const [seconds, setSeconds] = useState<number>(0);
  
  useEffect(() => {
    const targetDate = new Date('May 6, 2026').getTime();
    
    const countdown = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetDate - now;
      
      setDays(Math.floor(distance / (1000 * 60 * 60 * 24)));
      setHours(Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)));
      setMinutes(Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)));
      setSeconds(Math.floor((distance % (1000 * 60)) / 1000));
      
      if (distance < 0) {
        clearInterval(countdown);
      }
    }, 1000);
    
    return () => clearInterval(countdown);
  }, []);

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-pink-50 to-teal-50 pt-16 px-4">
      {/* Floating elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div 
            key={i}
            className="absolute animate-float opacity-70"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 10}s`,
              animationDuration: `${15 + Math.random() * 10}s`
            }}
          >
            {i % 3 === 0 ? (
              <Heart size={20} className="text-pink-400" fill="#ec4899" />
            ) : i % 3 === 1 ? (
              <Star size={20} className="text-yellow-400" fill="#facc15" />
            ) : (
              <Calendar size={20} className="text-teal-400" />
            )}
          </div>
        ))}
      </div>
      
      {/* Main hero content */}
      <div className="relative z-10 text-center">
        <h1 className="text-5xl md:text-7xl font-dancing text-pink-600 mb-4">
          Happy Birthday
        </h1>
        <h2 className="text-4xl md:text-5xl font-dancing text-pink-500 mb-6">
          Rasheedha M
        </h2>
        <p className="text-xl md:text-2xl font-light text-gray-700 mb-8">
          <span className="font-medium">Shayin</span> to family, <span className="font-medium">Dhillu</span> to husband
        </p>
        
        {/* Birthday countdown */}
        <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-xl max-w-md mx-auto">
          <h3 className="text-lg md:text-xl font-medium text-gray-800 mb-4">Countdown to May 6, 2025</h3>
          <div className="grid grid-cols-4 gap-2 text-center">
            <div className="bg-pink-100 rounded-lg p-2">
              <div className="text-2xl md:text-3xl font-bold text-pink-600">{days}</div>
              <div className="text-xs text-gray-600">DAYS</div>
            </div>
            <div className="bg-pink-100 rounded-lg p-2">
              <div className="text-2xl md:text-3xl font-bold text-pink-600">{hours}</div>
              <div className="text-xs text-gray-600">HOURS</div>
            </div>
            <div className="bg-pink-100 rounded-lg p-2">
              <div className="text-2xl md:text-3xl font-bold text-pink-600">{minutes}</div>
              <div className="text-xs text-gray-600">MINUTES</div>
            </div>
            <div className="bg-pink-100 rounded-lg p-2">
              <div className="text-2xl md:text-3xl font-bold text-pink-600">{seconds}</div>
              <div className="text-xs text-gray-600">SECONDS</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;