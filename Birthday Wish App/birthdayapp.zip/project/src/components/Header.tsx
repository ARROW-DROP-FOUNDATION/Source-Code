import React from 'react';
import { Cake, Music, Music as MusicOff } from 'lucide-react';

interface HeaderProps {
  isMusicPlaying: boolean;
  toggleMusic: () => void;
}

const Header: React.FC<HeaderProps> = ({ isMusicPlaying, toggleMusic }) => {
  return (
    <header className="fixed top-0 w-full bg-gradient-to-r from-pink-100 to-pink-200 shadow-md z-50 px-4 py-2 flex justify-between items-center">
      <div className="flex items-center">
        <Cake className="text-pink-500 mr-2" size={24} />
        <h1 className="text-xl md:text-2xl font-dancing text-pink-600">Rasheedha's Birthday</h1>
      </div>
      <button 
        onClick={toggleMusic}
        className="p-2 rounded-full hover:bg-pink-300 transition-colors duration-300"
        aria-label={isMusicPlaying ? "Pause Music" : "Play Music"}
      >
        {isMusicPlaying ? 
          <MusicOff size={20} className="text-pink-700" /> : 
          <Music size={20} className="text-pink-700" />
        }
      </button>
    </header>
  );
};

export default Header;