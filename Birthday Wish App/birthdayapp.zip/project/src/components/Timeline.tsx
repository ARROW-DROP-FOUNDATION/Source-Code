import React from 'react';
import { timelineEvents } from '../data/wishes';
import { Calendar, GraduationCap, Heart, Baby } from 'lucide-react';

const Timeline: React.FC = () => {
  const getIcon = (title: string) => {
    if (title.includes('Born')) return <Baby className="text-pink-500" />;
    if (title.includes('Education')) return <GraduationCap className="text-blue-500" />;
    if (title.includes('Wedding')) return <Heart className="text-red-500" />;
    return <Calendar className="text-teal-500" />;
  };

  return (
    <section className="py-16 px-4 bg-gradient-to-b from-teal-50 to-pink-50">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-dancing text-center text-teal-600 mb-12">
          Life Journey
        </h2>
        
        <div className="relative">
          {/* Vertical timeline line */}
          <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 h-full w-1 bg-pink-200"></div>
          
          {/* Timeline events */}
          {timelineEvents.map((event, index) => (
            <div 
              key={index} 
              className={`mb-8 flex flex-col md:flex-row ${
                index % 2 === 0 ? 'md:flex-row-reverse' : ''
              }`}
            >
              <div className="md:w-1/2 flex justify-center md:justify-end md:pr-8 mb-4 md:mb-0">
                <div 
                  className={`w-full md:max-w-xs p-4 rounded-lg shadow-md bg-white border-l-4 ${
                    index % 3 === 0 ? 'border-pink-400' : 
                    index % 3 === 1 ? 'border-teal-400' : 'border-yellow-400'
                  }`}
                >
                  <div className="text-sm text-gray-500 mb-1">{event.date}</div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">{event.title}</h3>
                  <p className="text-gray-600">{event.description}</p>
                </div>
              </div>
              
              <div className="md:w-1/2 relative flex justify-center md:justify-start md:pl-8">
                {/* Timeline dot */}
                <div className="absolute left-0 md:left-0 top-6 transform md:translate-x-1/2 w-8 h-8 rounded-full bg-white shadow-md border-4 border-pink-300 flex items-center justify-center">
                  {getIcon(event.title)}
                </div>
                
                {/* Space holder for mobile layout */}
                <div className="md:hidden h-full w-8"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Timeline;