import React, { useState } from 'react';
import { familyWishes, friendWishes, husbandWish } from '../data/wishes';
import WishPopup from './WishPopup';
import { Heart, Users, User } from 'lucide-react';

const WishGallery: React.FC = () => {
  const [activeWishId, setActiveWishId] = useState<string | null>(null);
  
  const getActiveWish = () => {
    if (!activeWishId) return null;
    
    return [...familyWishes, ...friendWishes, husbandWish].find(wish => wish.id === activeWishId) || null;
  };
  
  const activeWish = getActiveWish();
  
  return (
    <section className="py-16 px-4 bg-gradient-to-b from-pink-50 to-purple-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-dancing text-center text-pink-600 mb-12">
          Birthday Wishes
        </h2>
        
        {/* Family wishes */}
        <div className="mb-12">
          <div className="flex items-center justify-center mb-6">
            <Users className="text-teal-500 mr-2" size={24} />
            <h3 className="text-2xl font-dancing text-teal-600">Family Wishes</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {familyWishes.map(wish => (
              <div 
                key={wish.id}
                onClick={() => setActiveWishId(wish.id)}
                className="bg-white p-4 rounded-lg shadow-md border-l-4 border-teal-400 cursor-pointer transform transition-transform hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="text-lg font-semibold text-teal-600 mb-1">{wish.name}</div>
                <div className="text-sm text-gray-500 mb-2">{wish.relationship}</div>
                <p className="text-gray-700 line-clamp-2">"{wish.message.substring(0, 50)}..."</p>
              </div>
            ))}
          </div>
        </div>
        
        {/* Friends wishes */}
        <div className="mb-12">
          <div className="flex items-center justify-center mb-6">
            <Users className="text-blue-500 mr-2" size={24} />
            <h3 className="text-2xl font-dancing text-blue-600">School Friends Wishes</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {friendWishes.map(wish => (
              <div 
                key={wish.id}
                onClick={() => setActiveWishId(wish.id)}
                className="bg-white p-4 rounded-lg shadow-md border-l-4 border-blue-400 cursor-pointer transform transition-transform hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="text-lg font-semibold text-blue-600 mb-1">{wish.name}</div>
                <div className="text-sm text-gray-500 mb-2">{wish.relationship}</div>
                <p className="text-gray-700 line-clamp-2">"{wish.message.substring(0, 50)}..."</p>
              </div>
            ))}
          </div>
        </div>
        
        {/* Husband wish - special style */}
        <div>
          <div className="flex items-center justify-center mb-6">
            <Heart className="text-pink-500 mr-2" size={24} fill="#ec4899" />
            <h3 className="text-2xl font-dancing text-pink-600">Special Wish</h3>
          </div>
          
          <div 
            onClick={() => setActiveWishId(husbandWish.id)}
            className="bg-gradient-to-r from-pink-100 to-pink-200 p-6 rounded-lg shadow-lg border border-pink-300 cursor-pointer max-w-2xl mx-auto text-center hover:shadow-xl transition-shadow"
          >
            <div className="text-xl font-dancing text-pink-600 mb-1">{husbandWish.name}</div>
            <div className="text-sm text-gray-600 mb-4">{husbandWish.relationship}</div>
            <p className="text-gray-700 italic">
              "A special message waiting for you..."
            </p>
            <div className="mt-4 flex justify-center">
              <User className="text-pink-500 mr-1" size={18} />
              <span className="text-sm text-pink-500">Click to read</span>
            </div>
          </div>
        </div>
        
        {/* Popup */}
        {activeWish && (
          <WishPopup 
            wish={activeWish} 
            isOpen={!!activeWishId} 
            onClose={() => setActiveWishId(null)} 
          />
        )}
      </div>
    </section>
  );
};

export default WishGallery;